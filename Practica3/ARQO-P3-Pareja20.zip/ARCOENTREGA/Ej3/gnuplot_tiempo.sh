gnuplot << END_GNUPLOT
set title "Multiplicacion de matrices"
set ylabel "Execution time (s)"
set xlabel "Matrix Size"
set key right bottom
set grid
set term png
set output "mult_time.png"
plot "mult.dat" using 1:2 with lines lw 2 title "normal", \
     "mult.dat" using 1:5 with lines lw 2 title "trasp"
replot
quit
END_GNUPLOT
