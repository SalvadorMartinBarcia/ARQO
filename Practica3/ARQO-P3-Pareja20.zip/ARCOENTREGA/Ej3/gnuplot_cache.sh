gnuplot << END_GNUPLOT
set title "Multiplicacion de matrices"
set ylabel "Number of errors"
set xlabel "Matrix Size"
set key right bottom
set grid
set term png
set output "mult_time.png"
plot "mult.dat" using 1:3 with lines lw 2 title "normal_mr", \
	 "mult.dat" using 1:4 with lines lw 2 title "normal_mw", \
	 "mult.dat" using 1:6 with lines lw 2 title "trasp_mr", \
     "mult.dat" using 1:7 with lines lw 2 title "trasp_mw"
replot
quit
END_GNUPLOT
